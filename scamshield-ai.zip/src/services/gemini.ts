import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface AnalysisResult {
  riskScore: number;
  riskLevel: "Low" | "Medium" | "High";
  explanation: string;
  recommendedAction: string;
  findings: string[];
  ownerInfo: string;
}

export async function analyzeInput(type: string, content: string, imageData?: string): Promise<AnalysisResult> {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are ScamShield AI, a world-class fraud detection expert.
    Analyze the provided input and determine if it is a scam.
    Input Type: ${type}
    Input Content: ${content}
    ${imageData ? "An image has been provided for visual analysis." : ""}

    Consider:
    - Urgency triggers and emotional manipulation
    - Guaranteed profit claims
    - Impersonation signals
    - Poor grammar patterns
    - Suspicious links or domains
    - Crypto-specific risks (honeypots, rug pulls, suspicious wallet behavior)
    - For images: Look for fake UI, suspicious logos, or deceptive text in screenshots.

    Return a JSON response with:
    - riskScore (0-100)
    - riskLevel (Low, Medium, High)
    - explanation (A concise summary of why it's risky or safe)
    - recommendedAction (Avoid, Caution, or Likely Safe)
    - findings (An array of specific red flags or positive indicators)
    - ownerInfo (The name of the CEO, Founder, or likely owner of the platform/service mentioned. If you can't find the exact name, provide the most likely entity or individual responsible.)
  `;

  const parts: any[] = [{ text: "Analyze this input for scams." }];
  
  if (imageData) {
    // Extract base64 data if it's a data URL
    const base64Data = imageData.includes(",") ? imageData.split(",")[1] : imageData;
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: base64Data,
      },
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          riskScore: { type: Type.NUMBER },
          riskLevel: { type: Type.STRING },
          explanation: { type: Type.STRING },
          recommendedAction: { type: Type.STRING },
          ownerInfo: { type: Type.STRING },
          findings: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["riskScore", "riskLevel", "explanation", "recommendedAction", "findings", "ownerInfo"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}
